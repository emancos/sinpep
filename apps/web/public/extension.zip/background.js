// background.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'PING') {
    sendResponse({ status: 'OK', version: chrome.runtime.getManifest().version });
    return true;
  }

  if (request.action === 'PROXY_FETCH') {
    handleProxyFetch(request)
      .then(sendResponse)
      .catch((error) => {
        console.error('Fetch error:', error);
        sendResponse({ error: error.message || String(error), stack: error.stack });
      });
    
    // Retorna true indicando que sendResponse será chamado assincronamente
    return true; 
  }
});

async function handleProxyFetch({ url, method = 'GET', headers = {}, body = null }) {
  try {
    const fetchOptions = {
      method,
      headers: { ...headers },
      credentials: 'omit', // Extensões MV3 com fetch podem usar cookies do navegador se omit for removido ou usar include, vamos deixar include.
    };
    fetchOptions.credentials = 'include';

    if (body && (method === 'POST' || method === 'PUT')) {
      fetchOptions.body = body;
    }

    const response = await fetch(url, fetchOptions);
    
    // Ler os bytes brutos para lidar com o encoding iso-8859-1 do SISREG
    const buffer = await response.arrayBuffer();
    
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);

    const decoder = new TextDecoder('iso-8859-1');
    const text = decoder.decode(buffer);

    return {
      status: response.status,
      statusText: response.statusText,
      url: response.url,
      html: text,
      base64: base64,
    };
  } catch (error) {
    throw error;
  }
}
