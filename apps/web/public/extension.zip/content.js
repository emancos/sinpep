// content.js

// Escuta mensagens do React enviadas via window.postMessage
window.addEventListener("message", (event) => {
  // Segurança: aceitar apenas mensagens da própria janela e com nossa flag
  if (event.source !== window || !event.data || event.data.source !== "REACT_APP") return;

  if (event.data.action === "PROXY_FETCH") {
    try {
      chrome.runtime.sendMessage(
        { action: "PROXY_FETCH", ...event.data.payload },
        (response) => {
          window.postMessage({
            source: "EXTENSION",
            requestId: event.data.requestId,
            response
          }, "*");
        }
      );
    } catch (error) {
      if (error.message.includes("Extension context invalidated")) {
        console.error("Extensão foi recarregada. É necessário atualizar a aba (F5).");
        window.postMessage({
          source: "EXTENSION",
          requestId: event.data.requestId,
          response: { error: "Extensão atualizada. Por favor, atualize a página (F5)." }
        }, "*");
      } else {
        throw error;
      }
    }
  } else if (event.data.action === "PING") {
    // Responde ao ping caso o React monte depois da extensão carregar
    window.postMessage({ source: "EXTENSION_INIT" }, "*");
  }
});

// Anuncia para o React que a extensão está instalada
window.postMessage({ source: "EXTENSION_INIT" }, "*");
